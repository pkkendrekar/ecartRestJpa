package com.xoriant.ecart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.ecart.entities.Product;

//public interface ProductDao {
	public interface ProductDao extends JpaRepository<Product, Integer>{
		
		//@Query(value="SELECT * FROM Product WHERE product_price in (40000,500)", nativeQuery=true)
		
		
		
		//List<Product> findByBrandTitleLike(String brandTitle);

		//List<Product> findByBrandTitle(String string);
	}

