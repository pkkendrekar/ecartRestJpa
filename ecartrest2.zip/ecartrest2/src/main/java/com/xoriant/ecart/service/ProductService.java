package com.xoriant.ecart.service;

import java.util.List;
import java.util.Optional;

import com.xoriant.ecart.entities.Product;

public interface ProductService {
	// find all brands
	List<Product> findAllProducts();

	// find by brand id
	Product findProductById(int productId);

}
