package com.xoriant.ecart.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name = "products")
public class Product {
	@Id
	@GeneratedValue
	
	
	@Column(name="product_id")
	private int  productId;
	
	private int product_cat;
	private int product_brand;
	private String product_title;
	private int product_price;
	private int product_qty;
	private String product_desc;
	private String product_image;
	private String product_keywords;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getProduct_cat() {
		return product_cat;
	}
	public void setProduct_cat(int product_cat) {
		this.product_cat = product_cat;
	}
	public int getProduct_brand() {
		return product_brand;
	}
	public void setProduct_brand(int product_brand) {
		this.product_brand = product_brand;
	}
	public String getProduct_title() {
		return product_title;
	}
	public void setProduct_title(String product_title) {
		this.product_title = product_title;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public int getProduct_qty() {
		return product_qty;
	}
	public void setProduct_qty(int product_qty) {
		this.product_qty = product_qty;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public String getProduct_image() {
		return product_image;
	}
	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}
	public String getProduct_keywords() {
		return product_keywords;
	}
	public void setProduct_keywords(String product_keywords) {
		this.product_keywords = product_keywords;
	}
}