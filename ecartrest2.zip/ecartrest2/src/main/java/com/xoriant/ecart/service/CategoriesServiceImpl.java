package com.xoriant.ecart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.ecart.dao.CategoriesDao;
import com.xoriant.ecart.entities.Brand;
import com.xoriant.ecart.entities.Categories;
//import com.xoriant.ecart.service.CategoriesService;


@Service
public class CategoriesServiceImpl implements CategoriesService {
	@Autowired
	private CategoriesDao categoriesDao;

	// find all brands
	@Override
	public List<Categories> findAllCategoriess() {
	return categoriesDao.findAll();
	}

//	public List<Brand> findAllBrands() {
//		return brandDao.findAll();
}
