package com.xoriant.ecart.resource;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xoriant.ecart.entities.Brand;
import com.xoriant.ecart.entities.Product;
import com.xoriant.ecart.service.ProductService;

@RestController
@RequestMapping("/api/products")
public class ProductsResource {
	
	/*
	 * requirements
	 * -------------------
	 *     GET
	 *     ---
	 * 1. List all Products
	 * 2. List all products by Brand Title
	 * 3. List all brands
	 * 4. List all categories
	 * 5. List all products by category name
	 * 6. List all products with in given price start and end range
	 * 7. List all products above given price range
	 * 8. List all orders of a given user id
	 * 
	 * -----------------------------------------------
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	
	
	@Autowired
	private ProductService productService;
	
	// find all brands
	@GetMapping
	public List<Product> findAllProducts(){
		return productService.findAllProducts();
	}

}



