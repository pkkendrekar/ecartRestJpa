package com.xoriant.ecart.entities;

public class Cart {

}
