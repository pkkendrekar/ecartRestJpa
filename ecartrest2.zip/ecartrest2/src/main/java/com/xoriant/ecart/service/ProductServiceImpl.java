package com.xoriant.ecart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.ecart.dao.ProductDao;
import com.xoriant.ecart.entities.Product;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao productDao;

	// find all brands
	@Override
	public List<Product> findAllProducts() {
		return productDao.findAll();
	}

	//@Override
	public Product findProductById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}