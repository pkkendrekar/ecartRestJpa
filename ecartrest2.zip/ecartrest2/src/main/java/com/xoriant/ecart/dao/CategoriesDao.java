package com.xoriant.ecart.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.ecart.entities.Brand;
import com.xoriant.ecart.entities.Categories;

public interface CategoriesDao extends JpaRepository<Categories, Integer>{

}
